location.href = '/browser-unsupported.html';
